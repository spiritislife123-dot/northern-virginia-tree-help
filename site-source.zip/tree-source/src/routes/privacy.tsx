import { createFileRoute } from '@tanstack/react-router'
import { PageShell } from '../components/PageShell'
import { enquiryForm, photoCredits, site } from '../data/site'

export const Route = createFileRoute('/privacy')({
  head: () => ({
    meta: [
      { title: `Privacy Policy | ${site.name}` },
      {
        name: 'description',
        content: `Privacy policy explaining how ${site.name} collects, uses and shares estimate requests.`,
      },
    ],
  }),
  component: PrivacyPage,
})

function PrivacyPage() {
  return (
    <PageShell>
      <article className="mx-auto max-w-3xl px-5 py-20 sm:px-8 sm:py-24">
        <p className="eyebrow">Privacy policy</p>
        <h1 className="mt-5 text-4xl font-medium text-forest-900 sm:text-5xl">
          How we handle your information
        </h1>
        <p className="mt-5 text-sm text-sage-700">
          This notice explains how {site.name} handles information submitted through this website.
        </p>

        <div className="prose-copy mt-8 space-y-8 text-[1.05rem] leading-relaxed text-forest-900/90">
          <section>
            <h2 className="text-2xl font-medium text-forest-900">Information we collect</h2>
            <p>
              When you submit an estimate request, we collect the information in the form, including your name, telephone number, ZIP code, the service you are asking about, your project description and your consent choice. The website hosting and form systems may also process technical information needed to operate, protect and troubleshoot the site.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-medium text-forest-900">How we use your information</h2>
            <p>
              We use the details you provide to review your request, identify whether the location and requested service are within the areas we coordinate, respond to you, prevent spam or duplicate submissions, and keep a record of the request.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-medium text-forest-900">When we share your information</h2>
            <p>
              We share your contact information and project details with <strong>one independent local tree-service provider</strong> only when you check the required consent box on the estimate request form. That provider may contact you to discuss your project and provide an estimate. We do not send the same request to multiple providers under this consent.
            </p>
            <blockquote className="border-l-4 border-copper-400 bg-ivory-100 p-5 italic">
              “{enquiryForm.consentText}”
            </blockquote>
            <p>
              The website hosting and form-processing companies may process submitted information on our behalf to operate the website and deliver form notifications. We do not sell or rent estimate-request contact information. The local provider is an independent business and is responsible for its own handling of your information after it receives your request. If that provider cannot assist and we need to send your request to a different provider, we will ask for your permission before sharing it again.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-medium text-forest-900">How long we keep information</h2>
            <p>
              We keep enquiry information only for as long as reasonably needed to respond to the request, administer the service, maintain appropriate business records, resolve questions or disputes, and meet applicable legal requirements.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-medium text-forest-900">Your choices and privacy requests</h2>
            <p>
              The consent checkbox is not selected by default, and the estimate form requires an affirmative consent choice before it can be submitted. If you do not want your estimate request shared with one independent local provider, do not submit that form. You can ask us to correct or delete information you submitted, subject to records we may be required or permitted to retain. For a privacy question or request, use the telephone contact published on this website and clearly identify it as a privacy matter. We will not forward a privacy-only request to a tree-service provider.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-medium text-forest-900">Security and third-party services</h2>
            <p>
              We use website hosting and form-processing services to operate this site. We take reasonable steps to limit access to enquiry information, but no website or electronic transmission can be guaranteed to be completely secure. This website may link to third-party websites; their privacy practices are governed by their own policies.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-medium text-forest-900">Children’s information</h2>
            <p>
              This website and its estimate-request service are intended for adults seeking tree work for a property. We do not knowingly seek personal information from children.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-medium text-forest-900">Changes to this policy</h2>
            <p>
              We may update this notice when our website or information-handling practices change. The current version will be posted on this page.
            </p>
          </section>
        </div>

        <h2 id="photography" className="mt-16 text-3xl font-medium text-forest-900">
          Photo credits
        </h2>
        <p className="mt-4 text-forest-900/90">
          Photography on this website is from{' '}
          <a href="https://www.pexels.com" className="underline decoration-copper-400 underline-offset-4">
            Pexels
          </a>{' '}
          and used under the Pexels License. Images are illustrative and do not represent completed work by a particular provider.
        </p>
        <ul className="mt-6 divide-y divide-forest-800/10 rounded-2xl bg-ivory-100 px-6">
          {photoCredits.map((credit) => (
            <li key={credit.url} className="flex flex-col gap-1 py-4 sm:flex-row sm:items-center sm:justify-between">
              <span className="text-forest-900">{credit.subject}</span>
              <a href={credit.url} className="text-sm text-copper-600 underline underline-offset-4" rel="noopener" target="_blank">
                View on Pexels
              </a>
            </li>
          ))}
        </ul>
      </article>
    </PageShell>
  )
}
