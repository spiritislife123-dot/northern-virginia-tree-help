import { createFileRoute } from '@tanstack/react-router'
import { LogoMark } from '../components/Logo'
import { PageShell } from '../components/PageShell'
import { PhoneNumber } from '../components/SiteHeader'
import { site } from '../data/site'

export const Route = createFileRoute('/thank-you')({
  head: () => ({
    meta: [
      { title: `Thank you | ${site.name}` },
      { name: 'robots', content: 'noindex' },
    ],
  }),
  component: ThankYouPage,
})

const nextSteps = [
  'We review the details of your request.',
  'Your request is shared with one independent local tree-service provider who serves your area.',
  'They contact you by telephone to discuss the job and arrange your estimate.',
]

function ThankYouPage() {
  return (
    <PageShell>
      <section className="bg-ivory-100">
        <div className="mx-auto max-w-3xl px-5 py-24 text-center sm:px-8 sm:py-32">
          <LogoMark className="mx-auto h-20 w-20" />
          <p className="eyebrow mt-8 justify-center">Request received</p>
          <h1 className="mt-5 text-4xl font-medium text-forest-900 sm:text-5xl">
            Thank you for your estimate request.
          </h1>
          <p className="mx-auto mt-6 max-w-xl text-lg text-sage-700">
            We have received your details. Here is what happens next.
          </p>
          <ol className="mx-auto mt-12 max-w-xl space-y-4 text-left">
            {nextSteps.map((step, index) => (
              <li key={step} className="flex gap-4 rounded-2xl bg-ivory-50 p-5 ring-1 ring-forest-800/5">
                <span className="font-display flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-forest-800 text-ivory-50">
                  {index + 1}
                </span>
                <span className="pt-1 text-forest-900">{step}</span>
              </li>
            ))}
          </ol>
          <p className="mt-10 text-[0.95rem] text-sage-700">
            Need to add something to your request? Call{' '}
            <PhoneNumber className="font-semibold text-forest-800" />.
          </p>
          <div className="mt-10 flex flex-col justify-center gap-3 sm:flex-row">
            <a href="/" className="btn btn-forest">
              Return to the homepage
            </a>
            <a href="/#services" className="btn btn-ghost">
              Browse our services
            </a>
          </div>
        </div>
      </section>
    </PageShell>
  )
}
