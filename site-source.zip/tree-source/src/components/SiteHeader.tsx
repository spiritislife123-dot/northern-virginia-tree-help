import { useEffect, useState } from 'react'
import { phone, phoneIsPlaceholder } from '../data/site'
import { Logo } from './Logo'

export const navLinks = [
  { href: '/#services', label: 'Services' },
  { href: '/#why-us', label: 'Why Choose Us' },
  { href: '/#how-it-works', label: 'How It Works' },
  { href: '/#service-areas', label: 'Service Areas' },
  { href: '/#contact', label: 'Contact' },
]

export function PhoneNumber({ className = '' }: { className?: string }) {
  if (phoneIsPlaceholder)
    return (
      <span
        className={className}
        title="Telephone number coming soon"
        data-phone-placeholder
      >
        {phone.display}
      </span>
    )
  return (
    <a href={`tel:${phone.tel}`} className={className}>
      {phone.display}
    </a>
  )
}

function PhoneIcon({ className = '' }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
      <path d="M5 4h3l1.6 4.2-2 1.3a11 11 0 0 0 6.9 6.9l1.3-2L20 16v3a1.5 1.5 0 0 1-1.6 1.5C10.6 20 4 13.4 3.5 5.6A1.5 1.5 0 0 1 5 4Z" />
    </svg>
  )
}

/** Header. `overlay` renders it transparent over a dark hero until the page scrolls. */
export function SiteHeader({ overlay = false }: { overlay?: boolean }) {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    if (!open) return
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setOpen(false)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open])

  const solid = !overlay || scrolled || open
  const linkTone = solid
    ? 'text-forest-900 hover:text-copper-500'
    : 'text-ivory-100 hover:text-white'

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        solid
          ? 'bg-ivory-50/95 shadow-[0_1px_0_rgba(29,58,45,0.08),0_10px_30px_-20px_rgba(15,33,25,0.35)] backdrop-blur'
          : 'bg-gradient-to-b from-forest-950/60 to-transparent'
      }`}
    >
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between gap-6 px-5 sm:px-8">
        <a href="/" aria-label="Northern Virginia Tree Help home" className="shrink-0">
          <Logo tone={solid ? 'forest' : 'ivory'} />
        </a>

        <nav aria-label="Main" className="hidden lg:block">
          <ul className="flex items-center gap-7 text-[0.95rem] font-medium">
            {navLinks.map((link) => (
              <li key={link.href}>
                <a href={link.href} className={`transition-colors ${linkTone}`}>
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div className="hidden items-center gap-5 lg:flex">
          <span className={`flex items-center gap-2 text-sm font-semibold ${solid ? 'text-forest-800' : 'text-ivory-100'}`}>
            <PhoneIcon className="h-4 w-4" />
            <PhoneNumber />
          </span>
          <a href="/#contact" className="btn btn-primary px-5 py-3 text-sm">
            Request an Estimate
          </a>
        </div>

        <button
          type="button"
          className={`inline-flex h-11 w-11 items-center justify-center rounded-full lg:hidden ${solid ? 'text-forest-900 hover:bg-forest-800/5' : 'text-ivory-50 hover:bg-white/10'}`}
          aria-expanded={open}
          aria-controls="mobile-menu"
          aria-label={open ? 'Close menu' : 'Open menu'}
          onClick={() => setOpen((value) => !value)}
        >
          <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" aria-hidden="true">
            {open ? <path d="M6 6l12 12M18 6 6 18" /> : <path d="M4 7h16M4 12h16M4 17h16" />}
          </svg>
        </button>
      </div>

      <div
        id="mobile-menu"
        hidden={!open}
        className="border-t border-forest-800/10 bg-ivory-50 lg:hidden"
      >
        <nav aria-label="Mobile" className="mx-auto max-w-7xl px-5 pb-8 pt-3 sm:px-8">
          <ul className="divide-y divide-forest-800/10">
            {navLinks.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  onClick={() => setOpen(false)}
                  className="font-display block py-4 text-xl text-forest-900"
                >
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
          <div className="mt-6 flex flex-col gap-4">
            <a href="/#contact" onClick={() => setOpen(false)} className="btn btn-primary w-full">
              Request an Estimate
            </a>
            <p className="flex items-center justify-center gap-2 text-sm font-semibold text-forest-800">
              <PhoneIcon className="h-4 w-4" />
              <PhoneNumber />
            </p>
          </div>
        </nav>
      </div>
    </header>
  )
}
