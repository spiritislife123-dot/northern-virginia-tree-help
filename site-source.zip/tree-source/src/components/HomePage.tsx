import { useState } from 'react'
import { img, imgSrcSet, serviceAreas, services, site } from '../data/site'
import { EstimateForm } from './EstimateForm'
import { LogoMark } from './Logo'
import { PhoneNumber, SiteHeader } from './SiteHeader'
import { SiteFooter } from './SiteFooter'

function Photo({
  src,
  alt,
  widths,
  sizes,
  className = '',
  priority = false,
}: {
  src: string
  alt: string
  widths: number[]
  sizes: string
  className?: string
  priority?: boolean
}) {
  return (
    <img
      src={img(src, widths[Math.floor(widths.length / 2)])}
      srcSet={imgSrcSet(src, widths)}
      sizes={sizes}
      alt={alt}
      loading={priority ? 'eager' : 'lazy'}
      fetchPriority={priority ? 'high' : undefined}
      decoding="async"
      className={className}
    />
  )
}

function Check() {
  return (
    <svg viewBox="0 0 20 20" className="mt-1 h-4 w-4 shrink-0 text-copper-500" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="m4.5 10.5 3.5 3.5 7.5-8" />
    </svg>
  )
}

function Pin() {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5 shrink-0 text-copper-500" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M12 21s-6.5-5.6-6.5-11a6.5 6.5 0 0 1 13 0c0 5.4-6.5 11-6.5 11Z" />
      <circle cx="12" cy="10" r="2.3" />
    </svg>
  )
}

const reasons = [
  {
    title: 'One simple request',
    text: 'Tell us about your project once. We coordinate your request with an independent local tree-service professional who can discuss the job with you.',
  },
  {
    title: 'Local professionals',
    text: 'Requests are coordinated with an independent tree-service professional who works in your part of Northern Virginia.',
  },
  {
    title: 'An estimate before any work',
    text: 'The professional who would carry out the job provides your estimate, so you know what is proposed before agreeing to anything.',
  },
  {
    title: 'Respect for your property',
    text: 'We ask about access, fences, gardens and nearby structures from the start, so the details that matter for your home are understood.',
  },
  {
    title: 'You stay in control',
    text: 'There is no pressure to proceed. Review your estimate, ask questions and decide in your own time whether to go ahead.',
  },
  {
    title: 'Straightforward communication',
    text: 'Clear answers and honest expectations, without inflated promises. We would rather explain the process than oversell it.',
  },
]

const steps = [
  {
    title: 'Tell us about your trees',
    text: 'Complete the short estimate request form with your ZIP code, the service you need and a description of the project.',
  },
  {
    title: 'We review your request',
    text: 'We look over the details and share them with one independent local tree-service provider who serves your area.',
  },
  {
    title: 'A local professional contacts you',
    text: 'The provider gets in touch to talk through the job and, where needed, arrange a time to see the trees in person.',
  },
  {
    title: 'Review your estimate',
    text: 'You receive your estimate directly and decide whether to go ahead. Scheduling and the work itself are arranged with the provider.',
  },
]

export function HomePage() {
  const [service, setService] = useState('')

  return (
    <div id="top" className="overflow-x-clip">
      <SiteHeader overlay />
      <main>
        {/* Hero */}
        <section className="relative isolate flex min-h-[640px] items-end overflow-hidden bg-forest-950 pb-16 pt-32 sm:min-h-[720px] lg:min-h-[92vh] lg:items-center lg:pb-24">
          <Photo
            src="/img/hero-arborist-canopy.avif"
            alt="Arborist in a helmet and harness cutting the top section of a tall tree trunk against a clear blue sky"
            widths={[768, 1280, 1920, 2400]}
            sizes="100vw"
            priority
            className="absolute inset-0 -z-20 h-full w-full object-cover object-[62%_30%]"
          />
          <div className="absolute inset-0 -z-10 bg-gradient-to-t from-forest-950/95 via-forest-950/55 to-forest-950/25 lg:bg-gradient-to-r lg:from-forest-950/92 lg:via-forest-950/60 lg:to-forest-950/5" />
          <div className="mx-auto w-full max-w-7xl px-5 sm:px-8">
            <div className="max-w-2xl">
              <p className="eyebrow text-copper-300">Tree care for Northern Virginia homes</p>
              <h1 className="mt-6 text-[2.6rem] font-medium leading-[1.05] text-ivory-50 sm:text-6xl lg:text-[4.4rem]">
                Professional Tree Removal &amp; Trimming.
              </h1>
              <p className="font-display mt-5 text-2xl italic text-copper-300 sm:text-[1.85rem]">
                Your property deserves the right care.
              </p>
              <p className="mt-6 max-w-xl text-lg leading-relaxed text-ivory-100/90">
                We help Northern Virginia homeowners arrange professional tree
                removal and trimming services. From your first enquiry to
                arranging your estimate, we’re here to make the process
                straightforward.
              </p>
              <div className="mt-9 flex flex-col gap-3 sm:flex-row sm:items-center">
                <a href="#contact" className="btn btn-primary py-4">
                  Request an Estimate <span aria-hidden="true">→</span>
                </a>
                <a href="#services" className="btn btn-ghost-light py-4">
                  Explore Our Services
                </a>
              </div>
              <p className="mt-8 text-sm text-ivory-100/75">
                Prefer to talk? Call{' '}
                <PhoneNumber className="font-semibold text-ivory-50" />
              </p>
            </div>
          </div>
        </section>

        {/* Area ribbon */}
        <div className="border-b border-forest-800/10 bg-ivory-100">
          <div className="mx-auto flex max-w-7xl flex-col gap-3 px-5 py-5 text-sm sm:px-8 md:flex-row md:items-center md:justify-between">
            <p className="font-semibold uppercase tracking-[0.18em] text-sage-700">
              Serving Northern Virginia
            </p>
            <ul className="flex flex-wrap gap-x-6 gap-y-2 text-forest-800">
              {serviceAreas.map((area) => (
                <li key={area.name} className="flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rounded-full bg-copper-400" aria-hidden="true" />
                  {area.name}
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Services */}
        <section id="services" aria-labelledby="services-heading" className="py-24 sm:py-28">
          <div className="mx-auto max-w-7xl px-5 sm:px-8">
            <div className="grid gap-8 lg:grid-cols-[1fr_1fr] lg:items-end">
              <div>
                <p className="eyebrow">What we can help with</p>
                <h2 id="services-heading" className="mt-5 text-4xl font-medium text-forest-900 sm:text-5xl">
                  Our Tree Services
                </h2>
              </div>
              <p className="max-w-xl text-lg text-sage-700 lg:justify-self-end">
                Whether it is a single overgrown maple or a storm-felled oak
                across the yard, we coordinate the work with independent local
                tree-service professionals and keep you informed from the
                first conversation.
              </p>
            </div>

            <div className="mt-14 grid gap-8 md:grid-cols-2">
              {services.map((item, index) => (
                <article
                  key={item.id}
                  id={item.id}
                  className="group flex flex-col overflow-hidden rounded-[1.75rem] bg-white shadow-[0_24px_60px_-36px_rgba(15,33,25,0.45)] ring-1 ring-forest-800/5"
                >
                  <div className="relative aspect-[16/11] overflow-hidden">
                    <Photo
                      src={item.image}
                      alt={item.imageAlt}
                      widths={[480, 720, 960, 1280]}
                      sizes="(min-width: 768px) 50vw, 100vw"
                      className="h-full w-full object-cover transition duration-700 group-hover:scale-[1.04]"
                    />
                    <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-forest-950/70 to-transparent" />
                    <span className="font-display absolute bottom-5 left-6 text-5xl font-medium text-ivory-50/90">
                      0{index + 1}
                    </span>
                  </div>
                  <div className="flex flex-1 flex-col p-7 sm:p-9">
                    <h3 className="text-[1.75rem] font-medium text-forest-900">{item.name}</h3>
                    <p className="mt-3 text-sage-700">{item.summary}</p>
                    <ul className="mt-6 space-y-2.5 text-[0.97rem] text-forest-900">
                      {item.includes.map((line) => (
                        <li key={line} className="flex gap-3">
                          <Check />
                          {line}
                        </li>
                      ))}
                    </ul>
                    <div className="mt-auto pt-8">
                      <a
                        href="#contact"
                        onClick={() => setService(item.name)}
                        className="btn btn-forest"
                        aria-label={`Request an estimate for ${item.name.toLowerCase()}`}
                      >
                        Request an Estimate <span aria-hidden="true">→</span>
                      </a>
                    </div>
                  </div>
                </article>
              ))}
            </div>
            <p className="mt-8 text-sm leading-relaxed text-sage-700">
              Specific services, methods and availability vary by independent local
              provider and property. The professional will confirm what can be
              offered after reviewing your request.
            </p>
          </div>
        </section>

        {/* Why choose us */}
        <section id="why-us" aria-labelledby="why-heading" className="relative overflow-hidden bg-forest-900 py-24 text-ivory-100 sm:py-28">
          <LogoMark tone="ivory" className="pointer-events-none absolute -right-24 -top-16 h-[520px] w-[520px] opacity-[0.04]" />
          <div className="relative mx-auto grid max-w-7xl gap-16 px-5 sm:px-8 lg:grid-cols-[0.95fr_1.05fr] lg:items-center">
            <div className="relative">
              <div className="overflow-hidden rounded-[1.75rem]">
                <Photo
                  src="/img/residential-home.avif"
                  alt="Brick Northern Virginia-style family home framed by mature shade trees and a neatly kept lawn"
                  widths={[600, 900, 1200, 1600]}
                  sizes="(min-width: 1024px) 45vw, 100vw"
                  className="aspect-[4/5] w-full object-cover sm:aspect-[5/4] lg:aspect-[4/5]"
                />
              </div>
              <div className="relative -mt-20 ml-6 mr-6 rounded-2xl bg-ivory-50 p-6 text-forest-900 shadow-2xl sm:absolute sm:-bottom-10 sm:-right-6 sm:ml-0 sm:mr-0 sm:mt-0 sm:max-w-xs">
                <p className="font-display text-xl leading-snug">
                  “One simple request. Clear next steps. Local professional support.”
                </p>
                <p className="mt-3 text-sm text-sage-700">How we approach every enquiry</p>
              </div>
            </div>

            <div>
              <p className="eyebrow text-copper-300">Why homeowners choose us</p>
              <h2 id="why-heading" className="mt-5 text-4xl font-medium text-ivory-50 sm:text-5xl">
                Tree work, arranged with care.
              </h2>
              <p className="mt-5 max-w-xl text-lg text-ivory-100/75">
                Finding the right people for tree work can be time-consuming.
                We keep it simple, considerate and clear from start to finish.
              </p>
              <div className="mt-12 grid gap-x-10 gap-y-9 sm:grid-cols-2">
                {reasons.map((reason) => (
                  <div key={reason.title} className="border-t border-ivory-100/15 pt-5">
                    <h3 className="text-xl font-medium text-ivory-50">{reason.title}</h3>
                    <p className="mt-2 text-[0.97rem] leading-relaxed text-ivory-100/70">{reason.text}</p>
                  </div>
                ))}
              </div>
              <a href="#contact" className="btn btn-primary mt-12">
                Request an Estimate <span aria-hidden="true">→</span>
              </a>
            </div>
          </div>
        </section>

        {/* How it works */}
        <section id="how-it-works" aria-labelledby="how-heading" className="py-24 sm:py-28">
          <div className="mx-auto max-w-7xl px-5 sm:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="eyebrow">How it works</p>
              <h2 id="how-heading" className="mt-5 text-4xl font-medium text-forest-900 sm:text-5xl">
                From first enquiry to your estimate
              </h2>
              <p className="mt-5 text-lg text-sage-700">
                Four simple steps, with no obligation to proceed until you
                have reviewed your estimate.
              </p>
            </div>

            <ol className="relative mt-16 grid gap-10 md:grid-cols-2 lg:grid-cols-4 lg:gap-8">
              <span className="absolute left-[12%] right-[12%] top-8 hidden h-px bg-gradient-to-r from-sage-300 via-copper-300 to-sage-300 lg:block" aria-hidden="true" />
              {steps.map((step, index) => (
                <li key={step.title} className="relative flex gap-5 lg:flex-col lg:items-center lg:text-center">
                  <span className="font-display relative flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-ivory-50 text-2xl text-forest-800 ring-1 ring-sage-300">
                    {index + 1}
                  </span>
                  <div>
                    <h3 className="text-xl font-medium text-forest-900 lg:mt-6">{step.title}</h3>
                    <p className="mt-2 text-[0.97rem] text-sage-700">{step.text}</p>
                  </div>
                </li>
              ))}
            </ol>

            <div className="mx-auto mt-16 flex max-w-4xl flex-col items-start gap-6 rounded-[1.5rem] bg-sage-200/50 p-7 ring-1 ring-sage-300/60 sm:flex-row sm:items-center sm:p-9">
              <LogoMark className="h-14 w-14 shrink-0" />
              <p className="text-[0.98rem] leading-relaxed text-forest-900">
                <strong className="font-semibold">How we work.</strong>{' '}
                {site.name} coordinates estimates and tree-service work with
                independent local professionals. The professional who contacts
                you provides your estimate and, if you choose to go ahead,
                schedules and carries out the work.
              </p>
            </div>
          </div>
        </section>

        {/* Service areas */}
        <section id="service-areas" aria-labelledby="areas-heading" className="bg-ivory-100 py-24 sm:py-28">
          <div className="mx-auto grid max-w-7xl gap-14 px-5 sm:px-8 lg:grid-cols-[1.1fr_0.9fr] lg:items-center">
            <div>
              <p className="eyebrow">Service areas</p>
              <h2 id="areas-heading" className="mt-5 text-4xl font-medium text-forest-900 sm:text-5xl">
                Serving homes across Northern Virginia
              </h2>
              <p className="mt-5 max-w-xl text-lg text-sage-700">
                We arrange tree removal, trimming, storm-damage and cleanup
                estimates for homeowners in the following communities.
              </p>
              <ul className="mt-10 grid gap-4 sm:grid-cols-2">
                {serviceAreas.map((area) => (
                  <li key={area.name} className="flex gap-4 rounded-2xl bg-ivory-50 p-5 ring-1 ring-forest-800/5">
                    <Pin />
                    <div>
                      <p className="font-display text-lg font-medium text-forest-900">
                        {area.name}
                        <span className="sr-only">, Virginia</span>
                      </p>
                      <p className="mt-0.5 text-sm text-sage-700">{area.note}</p>
                    </div>
                  </li>
                ))}
              </ul>
              <p className="mt-8 text-[0.95rem] text-sage-700">
                Not sure whether your address is covered? Include your ZIP
                code in your request and we will let you know.
              </p>
            </div>
            <div className="relative">
              <div className="overflow-hidden rounded-[1.75rem]">
                <Photo
                  src="/img/residential-autumn-street.avif"
                  alt="Tall autumn shade trees lining a quiet residential street in front of a white two-storey house"
                  widths={[600, 900, 1200, 1600]}
                  sizes="(min-width: 1024px) 40vw, 100vw"
                  className="aspect-[4/5] w-full object-cover sm:aspect-[3/2] lg:aspect-[4/5]"
                />
              </div>
            </div>
          </div>
        </section>

        {/* CTA band */}
        <section aria-label="Request an estimate" className="relative isolate overflow-hidden bg-forest-800">
          <Photo
            src="/img/service-trimming-pruning.avif"
            alt=""
            widths={[768, 1280, 1920]}
            sizes="100vw"
            className="absolute inset-0 -z-20 h-full w-full object-cover object-[50%_30%] opacity-35"
          />
          <div className="absolute inset-0 -z-10 bg-gradient-to-r from-forest-950/90 via-forest-900/80 to-forest-900/60" />
          <div className="mx-auto flex max-w-7xl flex-col items-start gap-8 px-5 py-20 sm:px-8 lg:flex-row lg:items-center lg:justify-between">
            <div className="max-w-2xl">
              <h2 className="text-3xl font-medium text-ivory-50 sm:text-[2.6rem] sm:leading-tight">
                Have a tree that needs attention?
              </h2>
              <p className="mt-4 text-lg text-ivory-100/80">
                Tell us what is going on and we will help you arrange an
                estimate with a local tree-service professional.
              </p>
            </div>
            <a href="#contact" className="btn btn-primary shrink-0 py-4 text-base">
              Request an Estimate <span aria-hidden="true">→</span>
            </a>
          </div>
        </section>

        {/* Contact */}
        <section id="contact" aria-labelledby="contact-heading" className="py-24 sm:py-28">
          <div className="mx-auto grid max-w-7xl gap-14 px-5 sm:px-8 lg:grid-cols-[0.85fr_1.15fr]">
            <div>
              <p className="eyebrow">Contact</p>
              <h2 id="contact-heading" className="mt-5 text-4xl font-medium text-forest-900 sm:text-5xl">
                Request an Estimate
              </h2>
              <p className="mt-5 text-lg text-sage-700">
                Share a few details about your trees and we will take it from
                there. A local tree-service professional will contact you to
                discuss your estimate.
              </p>

              <div className="mt-10 rounded-2xl bg-forest-900 p-7 text-ivory-100">
                <p className="text-xs font-semibold uppercase tracking-[0.2em] text-sage-300">
                  Call us
                </p>
                <p className="font-display mt-2 text-3xl text-ivory-50">
                  <PhoneNumber />
                </p>
                <p className="mt-3 text-sm text-ivory-100/70">
                  Serving Springfield, Burke, Fairfax County, Alexandria,
                  Arlington and Prince William County.
                </p>
              </div>

              <div className="mt-10">
                <h3 className="text-xl font-medium text-forest-900">Helpful details to include</h3>
                <ul className="mt-4 space-y-2.5 text-[0.97rem] text-forest-900">
                  {[
                    'The type and rough size of the tree, if you know it',
                    'Where it sits on the property and how easy it is to reach',
                    'Anything nearby: the house, fences, sheds, walkways or a driveway',
                    'Whether there is storm damage or any urgency',
                  ].map((line) => (
                    <li key={line} className="flex gap-3">
                      <Check />
                      {line}
                    </li>
                  ))}
                </ul>
              </div>

              <p className="mt-10 rounded-xl border-l-4 border-copper-400 bg-ivory-100 p-5 text-[0.93rem] leading-relaxed text-forest-900">
                <strong className="font-semibold">Safety first.</strong> If a
                tree is touching power lines or there is immediate danger,
                keep well clear and contact your electric utility or call 911
                before anything else.
              </p>
            </div>

            <div>
              <EstimateForm service={service} onServiceChange={setService} />
            </div>
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  )
}
