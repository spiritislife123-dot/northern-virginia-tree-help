type MarkProps = {
  className?: string
  /** Colour of the letterforms; leaves always use the copper accent. */
  tone?: 'ivory' | 'forest'
  title?: string
}

/**
 * NV monogram. The N's diagonal doubles as the V's first arm; the outer stems
 * fork into branches at their tips and a central trunk opens into a small
 * canopy with copper leaves.
 */
export function LogoMark({ className, tone = 'forest', title }: MarkProps) {
  const ink = tone === 'ivory' ? '#f7f2e8' : '#1d3a2d'
  const leaf = tone === 'ivory' ? '#d9a57f' : '#a86c42'
  return (
    <svg
      viewBox="0 0 64 64"
      className={className}
      role={title ? 'img' : undefined}
      aria-hidden={title ? undefined : true}
      aria-label={title}
      fill="none"
      stroke={ink}
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {/* N stem, shared diagonal and V arm */}
      <path d="M14 51V18L32 51L50 18" strokeWidth="4.6" />
      {/* branching tips of the N and V */}
      <path d="M14 20.5L10.6 14.6M14 20.5L17.2 14.8" strokeWidth="2.3" />
      <path d="M50 20.5L46.8 14.8M50 20.5L53.4 14.6" strokeWidth="2.3" />
      {/* central trunk and canopy */}
      <path d="M32 51V28" strokeWidth="3" />
      <path d="M32 32.5L25.4 22.6M32 29.5V16.5M32 32.5L38.6 22.6" strokeWidth="1.9" />
      <path
        d="M25.4 22.6L22.6 17.4M25.4 22.6L28 17.2M32 16.5L29.6 12.2M32 16.5L34.4 12.2M38.6 22.6L41.4 17.4M38.6 22.6L36 17.2"
        strokeWidth="1.35"
      />
      <g fill={leaf} stroke="none">
        <ellipse cx="21.9" cy="15.6" rx="2.7" ry="1.15" transform="rotate(-62 21.9 15.6)" />
        <ellipse cx="28.6" cy="15.4" rx="2.7" ry="1.15" transform="rotate(-110 28.6 15.4)" />
        <ellipse cx="28.9" cy="10.4" rx="2.7" ry="1.15" transform="rotate(-62 28.9 10.4)" />
        <ellipse cx="35.1" cy="10.4" rx="2.7" ry="1.15" transform="rotate(62 35.1 10.4)" />
        <ellipse cx="35.4" cy="15.4" rx="2.7" ry="1.15" transform="rotate(110 35.4 15.4)" />
        <ellipse cx="42.1" cy="15.6" rx="2.7" ry="1.15" transform="rotate(62 42.1 15.6)" />
      </g>
      {/* ground line */}
      <path d="M9 56.5H55" stroke={leaf} strokeWidth="1.2" />
    </svg>
  )
}

export function Logo({
  tone = 'forest',
  className = '',
}: {
  tone?: 'ivory' | 'forest'
  className?: string
}) {
  const ivory = tone === 'ivory'
  return (
    <span className={`inline-flex items-center gap-3 ${className}`}>
      <LogoMark tone={tone} className="h-11 w-11 shrink-0" />
      <span className="flex flex-col leading-none">
        <span
          className={`text-[0.66rem] font-semibold uppercase tracking-[0.24em] ${ivory ? 'text-sage-300' : 'text-sage-700'}`}
        >
          Northern Virginia
        </span>
        <span
          className={`font-display mt-1 text-[1.42rem] font-medium ${ivory ? 'text-ivory-50' : 'text-forest-800'}`}
        >
          Tree Help
        </span>
      </span>
    </span>
  )
}
