import { LogoMark } from './Logo'
import { PageShell } from './PageShell'

export function NotFoundPage() {
  return (
    <PageShell>
      <section className="mx-auto max-w-2xl px-5 py-28 text-center sm:px-8">
        <LogoMark className="mx-auto h-16 w-16" />
        <h1 className="mt-8 text-4xl font-medium text-forest-900">Page not found</h1>
        <p className="mt-4 text-lg text-sage-700">
          The page you were looking for isn’t here. It may have moved, or the
          link may be incorrect.
        </p>
        <div className="mt-10 flex flex-col justify-center gap-3 sm:flex-row">
          <a href="/" className="btn btn-forest">Go to the homepage</a>
          <a href="/#contact" className="btn btn-primary">Request an Estimate</a>
        </div>
      </section>
    </PageShell>
  )
}
