import { useRef, useState, type FormEvent } from 'react'
import { useNavigate } from '@tanstack/react-router'
import { enquiryForm, services } from '../data/site'

type Status = 'idle' | 'pending' | 'error'

export const otherServiceOption = 'Not sure / more than one service'

export function EstimateForm({
  service,
  onServiceChange,
}: {
  service: string
  onServiceChange: (value: string) => void
}) {
  const [status, setStatus] = useState<Status>('idle')
  const submitting = useRef(false)
  const navigate = useNavigate()

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (submitting.current) return
    const body = new URLSearchParams()
    new FormData(event.currentTarget).forEach((value, key) =>
      body.append(key, String(value)),
    )
    submitting.current = true
    setStatus('pending')
    try {
      const response = await fetch(enquiryForm.endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: body.toString(),
        signal: AbortSignal.timeout(15000),
      })
      // A preview server without form handling returns the registration page itself.
      if (!response.ok || /\bdata-netlify\s*=/i.test(await response.text()))
        throw new Error('Estimate request was not accepted')
      await navigate({ to: '/thank-you' })
    } catch {
      setStatus('error')
    } finally {
      submitting.current = false
    }
  }

  return (
    <form
      name={enquiryForm.name}
      method="POST"
      action={enquiryForm.endpoint}
      data-netlify="true"
      netlify-honeypot="bot-field"
      onSubmit={submit}
      aria-busy={status === 'pending'}
      className="rounded-[1.75rem] bg-white p-6 shadow-[0_30px_80px_-40px_rgba(15,33,25,0.45)] ring-1 ring-forest-800/5 sm:p-10"
    >
      <input type="hidden" name="form-name" value={enquiryForm.name} />
      <input
        type="hidden"
        name="subject"
        value="New estimate request – Northern Virginia Tree Help"
      />
      <p hidden>
        <label>
          Leave this field empty
          <input name="bot-field" tabIndex={-1} autoComplete="off" />
        </label>
      </p>

      <fieldset disabled={status === 'pending'} className="space-y-5">
        <legend className="font-display text-2xl text-forest-900 sm:text-[1.75rem]">
          Request an estimate
        </legend>
        <p className="mt-2! text-[0.95rem] text-sage-700">
          All fields are required. It only takes a minute.
        </p>

        <div className="grid gap-5 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <label htmlFor="estimate-name" className="form-label">
              Name
            </label>
            <input
              id="estimate-name"
              name="name"
              autoComplete="name"
              required
              maxLength={100}
              className="form-input"
            />
          </div>
          <div>
            <label htmlFor="estimate-phone" className="form-label">
              Telephone number
            </label>
            <input
              id="estimate-phone"
              name="phone"
              type="tel"
              inputMode="tel"
              autoComplete="tel"
              required
              pattern="[0-9()+\-.\s]{10,20}"
              title="Please enter a 10-digit telephone number"
              placeholder="Your best callback number"
              className="form-input"
            />
          </div>
          <div>
            <label htmlFor="estimate-zip" className="form-label">
              ZIP code
            </label>
            <input
              id="estimate-zip"
              name="zip"
              inputMode="numeric"
              autoComplete="postal-code"
              required
              pattern="[0-9]{5}"
              maxLength={5}
              title="Please enter a 5-digit ZIP code"
              placeholder="22150"
              className="form-input"
            />
          </div>
          <div className="sm:col-span-2">
            <label htmlFor="estimate-service" className="form-label">
              Service requested
            </label>
            <div className="relative">
              <select
                id="estimate-service"
                name="service"
                required
                value={service}
                onChange={(event) => onServiceChange(event.target.value)}
                className="form-input appearance-none pr-12"
              >
                <option value="" disabled>
                  Choose a service…
                </option>
                {services.map((item) => (
                  <option key={item.id} value={item.name}>
                    {item.name}
                  </option>
                ))}
                <option value={otherServiceOption}>{otherServiceOption}</option>
              </select>
              <svg viewBox="0 0 20 20" aria-hidden="true" className="pointer-events-none absolute right-4 top-1/2 h-5 w-5 -translate-y-1/2 text-forest-800" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
                <path d="M5.5 7.5 10 12l4.5-4.5" />
              </svg>
            </div>
          </div>
          <div className="sm:col-span-2">
            <label htmlFor="estimate-description" className="form-label">
              Description of project
            </label>
            <textarea
              id="estimate-description"
              name="description"
              required
              minLength={10}
              maxLength={3000}
              rows={5}
              placeholder="For example: a large oak in the back yard leaning toward the house, roughly 60 ft tall. Good access through the side gate."
              className="form-input resize-y"
            />
          </div>
        </div>

        <label className="flex items-start gap-3 rounded-xl bg-ivory-100 p-4 text-[0.93rem] leading-relaxed text-forest-900">
          <input
            type="checkbox"
            name="consent"
            value="Yes, the customer agreed to the consent statement"
            required
            className="mt-1 h-5 w-5 shrink-0 rounded border-sage-400 accent-forest-700"
          />
          <span>{enquiryForm.consentText}</span>
        </label>

        <button type="submit" className="btn btn-primary w-full py-4 text-base sm:w-auto">
          {status === 'pending' ? 'Sending your request…' : 'Request My Estimate'}
          {status !== 'pending' && <span aria-hidden="true">→</span>}
        </button>

        <p role="status" className="sr-only">
          {status === 'pending' ? 'Sending your estimate request…' : ''}
        </p>
        {status === 'error' && (
          <p role="alert" className="rounded-xl border border-copper-400/40 bg-copper-300/10 p-4 text-[0.93rem] text-copper-600">
            We couldn’t send your request just now. Your details are still
            here, so please try again in a moment.
          </p>
        )}
      </fieldset>
    </form>
  )
}
