import { services, serviceAreas, site } from '../data/site'
import { Logo } from './Logo'
import { PhoneNumber, navLinks } from './SiteHeader'

export function SiteFooter() {
  const year = new Date().getFullYear()
  return (
    <footer className="bg-forest-950 text-ivory-200">
      <div className="mx-auto max-w-7xl px-5 pb-10 pt-16 sm:px-8">
        <div className="grid gap-12 lg:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div>
            <a href="/" aria-label={`${site.name} home`}>
              <Logo tone="ivory" />
            </a>
            <p className="mt-6 max-w-sm text-[0.95rem] leading-relaxed text-ivory-200/75">
              {site.name} helps homeowners arrange tree removal, trimming,
              storm-damage and cleanup estimates, coordinated with independent
              local tree-service professionals.
            </p>
            <a href="/#contact" className="btn btn-primary mt-7">
              Request an Estimate
            </a>
          </div>

          <div>
            <h2 className="font-sans text-xs font-semibold uppercase tracking-[0.2em] text-sage-300">
              Explore
            </h2>
            <ul className="mt-5 space-y-3 text-[0.95rem]">
              {navLinks.map((link) => (
                <li key={link.href}>
                  <a href={link.href} className="text-ivory-200/80 transition hover:text-copper-300">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h2 className="font-sans text-xs font-semibold uppercase tracking-[0.2em] text-sage-300">
              Services
            </h2>
            <ul className="mt-5 space-y-3 text-[0.95rem]">
              {services.map((service) => (
                <li key={service.id}>
                  <a href={`/#${service.id}`} className="text-ivory-200/80 transition hover:text-copper-300">
                    {service.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h2 className="font-sans text-xs font-semibold uppercase tracking-[0.2em] text-sage-300">
              Contact
            </h2>
            <ul className="mt-5 space-y-3 text-[0.95rem] text-ivory-200/80">
              <li>
                <span className="block text-xs uppercase tracking-wider text-ivory-200/50">
                  Telephone
                </span>
                <PhoneNumber className="font-semibold text-ivory-50" />
              </li>
              <li>
                <span className="block text-xs uppercase tracking-wider text-ivory-200/50">
                  Online
                </span>
                <a href="/#contact" className="transition hover:text-copper-300">
                  Estimate request form
                </a>
              </li>
              <li>
                <span className="block text-xs uppercase tracking-wider text-ivory-200/50">
                  Serving
                </span>
                {serviceAreas.map((area) => area.name).join(', ')}, Virginia
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-14 border-t border-ivory-200/10 pt-8 text-[0.82rem] leading-relaxed text-ivory-200/55">
          <p className="max-w-4xl">
            {site.name} coordinates estimate requests and tree-service work
            with independent local tree-service professionals. Estimates,
            scheduling and the work itself are provided by the independent
            professional who contacts you.
          </p>
          <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <p>
              © {year} {site.name}. All rights reserved.
            </p>
            <ul className="flex flex-wrap gap-x-6 gap-y-2">
              <li>
                <a href="/privacy" className="hover:text-copper-300">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="/privacy#photography" className="hover:text-copper-300">
                  Photo credits
                </a>
              </li>
              <li>
                <a href="#top" className="hover:text-copper-300">
                  Back to top ↑
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </footer>
  )
}
