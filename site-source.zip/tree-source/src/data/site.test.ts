import { readFileSync } from 'node:fs'
import { describe, expect, it } from 'vitest'
import { enquiryForm, phone, phoneIsPlaceholder, serviceAreas, services } from './site'

describe('site configuration', () => {
  it('keeps the placeholder phone number non-dialable until a real number is set', () => {
    expect(phone.display).toBe('(703) XXX-XXXX')
    expect(phoneIsPlaceholder).toBe(true)
  })

  it('lists the four services and excludes Loudoun County', () => {
    expect(services.map((s) => s.name)).toEqual([
      'Tree Removal',
      'Tree Trimming and Pruning',
      'Storm-Damaged Trees',
      'Tree Cleanup',
    ])
    expect(serviceAreas.some((a) => /loudoun/i.test(a.name + a.note))).toBe(false)
  })

  it('registers every submitted field with Netlify Forms', () => {
    const html = readFileSync('public/__forms.html', 'utf8')
    expect(html).toContain(`name="${enquiryForm.name}"`)
    for (const field of ['form-name', 'subject', 'name', 'phone', 'zip', 'service', 'description', 'consent', 'bot-field'])
      expect(html).toContain(`name="${field}"`)
    for (const service of services) expect(html).toContain(`<option>${service.name}</option>`)
    expect(html).toContain('value=\"Yes, the customer agreed to the consent statement\" required')
  })

  it('keeps the callback phone field generic and consent unchecked by default', () => {
    const form = readFileSync('src/components/EstimateForm.tsx', 'utf8')
    expect(form).toContain('placeholder=\"Your best callback number\"')
    expect(form).toContain('name=\"consent\"')
    expect(form).toContain('required')
    expect(form).not.toMatch(/name=\"consent\"[\s\S]{0,250}defaultChecked/)
  })

  it('does not advertise utility-line clearance as a trimming service', () => {
    const source = readFileSync('src/data/site.ts', 'utf8')
    expect(source).not.toMatch(/power drops|lines to the house/i)
    expect(source).toMatch(/roofs, gutters, driveways, walkways/i)
  })
})
