/**
 * Central business configuration for Northern Virginia Tree Help.
 *
 * PHONE NUMBER: replace the placeholder below once the 703 number is issued.
 * Set `display` to the formatted number and `tel` to the dialable form in
 * international format. While `tel` is empty the number
 * is shown as plain text (never as a clickable link) across the whole site.
 */
export const phone = {
  display: '(703) XXX-XXXX',
  tel: '',
}

export const phoneIsPlaceholder = phone.tel === ''

export const site = {
  name: 'Northern Virginia Tree Help',
  shortName: 'NoVA Tree Help',
  tagline: 'Your property deserves the right care.',
  description:
    'Northern Virginia Tree Help coordinates estimate requests for tree removal, trimming, storm-damage assessment and related cleanup options with independent local tree-service professionals serving Springfield, Burke, Fairfax County, Alexandria, Arlington and Prince William County.',
  region: 'Northern Virginia',
}

export type ServiceId = 'tree-removal' | 'trimming-pruning' | 'storm-damage' | 'tree-cleanup'

export type Service = {
  id: ServiceId
  name: string
  summary: string
  includes: string[]
  image: string
  imageAlt: string
}

export const services: Service[] = [
  {
    id: 'tree-removal',
    name: 'Tree Removal',
    summary:
      'For trees that are dead, declining, leaning toward the house or simply in the wrong place. The local professional will assess the tree, access and surrounding property before recommending the work.',
    includes: [
      'Whole-tree removal, subject to site assessment and provider availability',
      'Sectional take-downs may be available for suitable properties',
      'Stump grinding may be available on request, depending on the provider',
    ],
    image: '/img/service-tree-removal.avif',
    imageAlt:
      'Arborist in a harness cutting a section from a tall tree trunk as sawdust sprays',
  },
  {
    id: 'trimming-pruning',
    name: 'Tree Trimming and Pruning',
    summary:
      'Thoughtful pruning can improve a tree’s shape and help manage branches near roofs, gutters, driveways, walkways and nearby structures while preserving its natural character.',
    includes: [
      'Crown thinning and shaping, where appropriate',
      'Deadwood and hazard-limb removal, depending on provider availability',
      'Branch clearance from roofs, driveways, walkways and nearby structures',
    ],
    image: '/img/service-trimming-pruning.avif',
    imageAlt:
      'Arborist secured by climbing ropes working among the branches of a mature tree',
  },
  {
    id: 'storm-damage',
    name: 'Storm-Damaged Trees',
    summary:
      'After high winds, heavy snow or summer thunderstorms, we can help you request an assessment of broken limbs, split trunks and uprooted trees. Availability depends on the local provider and the urgency of the situation.',
    includes: [
      'Assessment of fallen or uprooted trees, where offered',
      'Assessment of hanging or split limbs, depending on provider availability',
      'Trees affecting fences, sheds or vehicles; availability varies by provider',
    ],
    image: '/img/service-storm-damage.avif',
    imageAlt:
      'Large uprooted tree lying across a lawn beside a house after a storm',
  },
  {
    id: 'tree-cleanup',
    name: 'Tree Cleanup',
    summary:
      'Some local professionals may also offer removal of branches, brush and leftover wood after tree work or a storm. Cleanup options vary by provider and project.',
    includes: [
      'Brush and branch removal may be available',
      'Wood chipping or log hauling may be available on request',
      'Yard cleanup options depend on the local provider',
    ],
    image: '/img/service-tree-cleanup.avif',
    imageAlt:
      'Worker feeding cut branches into a wood chipper in a residential neighborhood',
  },
]

export const serviceAreas = [
  {
    name: 'Springfield',
    note: 'Including West Springfield, Kingstowne and Newington',
  },
  { name: 'Burke', note: 'Including Burke Centre and surrounding neighborhoods' },
  {
    name: 'Fairfax County',
    note: 'Annandale, Fairfax, Vienna, Reston, McLean, Centreville and more',
  },
  { name: 'Alexandria', note: 'City of Alexandria and Fairfax County Alexandria addresses' },
  { name: 'Arlington', note: 'Arlington County neighborhoods' },
  {
    name: 'Prince William County',
    note: 'Woodbridge, Lake Ridge, Manassas area, Dale City and more',
  },
]

export const enquiryForm = {
  name: 'estimate-request',
  endpoint: '/__forms.html',
  consentText:
    'I agree that Northern Virginia Tree Help may share my contact information and project details with one independent local tree-service provider so they can contact me about my estimate request.',
}

/** Photography sourced from Pexels under the Pexels License (free for commercial use). */
export const photoCredits = [
  { subject: 'Arborist on a tree trunk (homepage banner)', url: 'https://www.pexels.com/photo/a-man-cutting-a-tree-6218318/' },
  { subject: 'Tree removal', url: 'https://www.pexels.com/photo/arborist-cutting-down-tree-trunk-safely-with-chainsaw-31127615/' },
  { subject: 'Tree trimming and pruning', url: 'https://www.pexels.com/photo/professional-arborist-climbing-tree-for-maintenance-34674271/' },
  { subject: 'Storm-damaged trees', url: 'https://www.pexels.com/photo/uprooted-tree-after-severe-storm-in-urban-area-32394146/' },
  { subject: 'Tree cleanup', url: 'https://www.pexels.com/photo/worker-operating-wood-chipper-in-suburban-setting-34581908/' },
  { subject: 'Residential home', url: 'https://www.pexels.com/photo/house-in-village-4682116/' },
  { subject: 'Autumn residential street', url: 'https://www.pexels.com/photo/charming-white-house-surrounded-by-autumn-trees-34515430/' },
]

/** Build a Netlify Image CDN URL so pages never ship full-resolution originals. */
export function img(src: string, width: number, quality = 72) {
  return `/.netlify/images?url=${encodeURIComponent(src)}&w=${width}&fm=webp&q=${quality}`
}

export function imgSrcSet(src: string, widths: number[]) {
  return widths.map((w) => `${img(src, w)} ${w}w`).join(', ')
}
