# Northern Virginia Tree Help

The customer-facing website for **Northern Virginia Tree Help**, a service brand that helps homeowners in Springfield, Burke, Fairfax County, Alexandria, Arlington and Prince William County, Virginia arrange professional tree removal, trimming, storm-damage and cleanup estimates. Estimates and tree work are coordinated with independent local tree-service professionals.

## What's on the site

- **Homepage** (`/`): photographic hero, Our Tree Services photo cards, Why Homeowners Choose Us, How It Works, Service Areas, an estimate call-to-action band, the Contact section with the estimate request form, and the footer.
- **Thank-you page** (`/thank-you`): shown after a successful estimate request.
- **Privacy Policy & photo credits** (`/privacy`): how request details are collected, used and shared, plus Pexels credits.
- A branded 404 page.

## Key technologies

- [TanStack Start](https://tanstack.com/start) + React 19, deployed on Netlify
- Tailwind CSS v4 (theme colours defined in `src/styles.css`)
- Netlify Forms for the estimate request form (honeypot spam protection plus Netlify's Akismet filtering)
- Netlify Image CDN for responsive, WebP-optimised photography
- Google Fonts: Fraunces (headings) and Source Sans 3 (body)

## Replacing the telephone number

The number is set in **one place**: the `phone` object at the top of `src/data/site.ts`.

```ts
export const phone = {
  display: '(703) XXX-XXXX', // replace with the issued number
  tel: '', // add the issued number in international dialable format; leave '' until issued
}
```

While `tel` is empty, the placeholder `(703) XXX-XXXX` is displayed everywhere as plain text, never as a clickable link. Once `tel` is filled in, every instance becomes a tap-to-call link.

## Privacy and consent

The estimate form requires an unchecked-by-default consent checkbox before it can be submitted. The request may be shared with one independent local tree-service provider. Do not send the same request to another provider unless the homeowner gives fresh permission. Review `/privacy` before publishing and keep the contact details there current.

## Receiving estimate requests by email

Submissions are collected under the **estimate-request** form in the Netlify dashboard (Project → Forms). To have each request emailed to you, open **Forms → Form notifications → Add notification → Email notification**, choose the `estimate-request` form and enter your address. Check the **Spam submissions** list occasionally in case a genuine request was filtered.

## Running locally

```bash
pnpm install
netlify dev        # full Netlify emulation including the Image CDN
# or
pnpm dev           # Vite only, at http://localhost:3000
pnpm test          # configuration and form-registration tests
```

Local previews do not process form submissions; the form shows a retry message instead of pretending to succeed.

## Photography

All photographs are from Pexels, used under the Pexels License (free for commercial use). Originals live in `public/img/`; the credits list is in `src/data/site.ts` and shown on `/privacy`.
